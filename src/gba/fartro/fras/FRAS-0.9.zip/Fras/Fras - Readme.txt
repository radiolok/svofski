F.R.A.S. - Free Realtime Audio System for Gameboy Advance
Current version: v0.9 20021104 0335
Athor: DannyBoy (dan@netbabyworld.com)

Fras was originaly developed to be the sound system of a
game I am working on. As it turned out, it was very easy
to break it out of the game and turn in into a own library.

Currently F.R.A.S. can play modfiles with different numbers
of channels (1/2/4/8/16/32) and can playback in different
frequencies (LOW: ~15768.72hz, MEDIUM: ~18157.92hz, HIGH:
~21024.96hz)

Effects supported:
0: Arpeggio
1: Slide up
2: Slide down
4: Vibrato
6: Vibrato/Volume slide
9: Sample offset
A: Volume slide
B: Position jump
C: Set volume
D: Pattern break
F : Set speed

More specs about fras can be found on the web
(www.gatesboy.com/fras).

Fras is free for all to do whatever with. Source is free
and the code can be used in both non-/comercial projects.
No strings attached, I promise! However, as the author of
F.R.A.S. doesn't take any responsibility for whatever trouble
this package may cause.

To use it you need to link with the Fras.lib (or the
sources). Also you need to use some interrupt handler and
you need to tell it to execute FrasTimer1Intr on a Timer
1 interrupt. It's pretty easy if you are using Jeff
Frohwein's crt0 (get it at www.devrs.com/gba). Then make
sure you either call FrasUpdateMixer manually each frame
or have an interrupt call it (v-counter preferably).
If you have problems getting stuff to work you can check
the example included (main.c) or mail me at dan@netbabyworld.com.
But don't ask about the chicken thing, or you'll just get
even more confused :)

Fras is created by DannyBoy, 2002. Gameboy Advance is a
registerd trademark of Nintendo Co., Ltd.

Things that will be in version 1.0:

* Modplayer: support all effects
* General: make it easier to implement depending on if one 
  uses FastIrqs or IntrTable or a totally different
  irq handler.
* General: Add a FrasUnInstall function.
* Soundeffectplayer: first of all implement it
* Soundeffectplayer: support both PCM and ADPCM

Things that might be in version 1.0:

* Modplayer: support more than protracker mods (s3m, xm?)







Version history:

Version 0.9 20021104 0335

* Modplayer: Added some effects. Now these effects are
  supported:
    0x09 Sample offset
    0x0B Jump to pattern
	0x0C Set volume
	0x0D Pattern break
	0x0F Set speed

* Modplayer: Rearranged things in FrasUpdateTick but
  it's still very messy...
* Mod2Fras: Made the output smaller. (period and effect
  stored in shorts)
* Modplayer: Added support for looping samples
* Mod2Fras: Added suport for looping samples
* Modplayer: now supports variable number of channels
* Modplayer: mix at a variable frquencies
* General: FrasInstall function that starts the irqs and dmas
    even if no sound is playing.
* General: FrasPauseMod function that pauses the mod.
* General: FrasUnPauseMod function that resumes the mod.
* Modplayer: Rewrote mixer to have a major speed boost.
* Mod2Fras: Fixed bug when more than 4 channels.
* Modplayer: Uses ~15% CPU per frame (4 channels with DMA
    running). Max I've seen is only slightly above (~17%)
  


Pre-release 20020829 0101

* Initial release.
* No clicks (?)
* Mixing @ 15768 Hz
* 4 Channels
* Protracker only
* Mod2Fras converter
* Uses max 25 % CPU per frame (with DMA running)
