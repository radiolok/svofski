#ifndef FONTHANDLER_H
#define FONTHANDLER_H

void InitTileFont(void);
void InitSpriteFont(void);

void Print(const char *str,const unsigned short pos);
void PrintHex(int num,const unsigned short pos);
void itoa(char *str,const unsigned val);

void SPrintHex(short num,unsigned short posx,const unsigned short posy);
void SPrintHexLong(long num,unsigned short posx,const unsigned short posy);


#endif
