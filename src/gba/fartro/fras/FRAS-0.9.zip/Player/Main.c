#define MULTIBOOT const int __gba_multiboot;
MULTIBOOT

#include "GBASys.h"
#include "FontHandler.h"
#include "Chicken.h"
#include "Font.h"

#include "Mods/Country.h"
#include "Fras/Fras.h"

extern volatile int fras_currentPatternLine;
extern volatile int fras_patternCounter;

void AgbMain(void){
  unsigned counter;
  unsigned tileCounter;
  
  REG_DISPSTAT=0x0020;
  REG_DISPCNT=0x0000;

  
  //First init palette
  //Font palette goes in palette 0 (16 offset)
  for(counter=0;counter<CHICKEN_PALETTE_COLORS;counter++){
    BG_PALETTE[counter]=ChickenPaletteData[counter];
  }
  
  InitTileFont();
  BG_PALETTE[0]=ChickenPaletteData[0];
  
  
  //Now copy the tiles  
  for(tileCounter=0;tileCounter<CHICKEN_NR_OF_TILES;tileCounter++){
    for(counter=0;counter<CHICKEN_TILESIZE;counter++){
      SCREEN_32K[(tileCounter*CHICKEN_TILESIZE)+counter]=ChickenTileData[tileCounter][counter];
    }
  }

  //Now clear the MAP_1 so that it doesn't contain alot of junk
  //the highest nibble is the palette
  for(counter=0;counter<30;counter++){
    for(tileCounter=0;tileCounter<20;tileCounter++){
      MAP_0[(tileCounter*32)+counter]=ChickenMapData[(tileCounter*30)+counter];
    }
  }
  REG_BG0CNT=0x008B;
  REG_DISPCNT=0x0340;
  
  REG_BG0HOFS=0;
  REG_BG0VOFS=0;
  
  REG_BLDMOD=0x00C2;
  
  for(counter=0;counter<16;counter++){
    REG_COLEY2=16-counter;
    while(REG_VCOUNT!=158);
    while(REG_VCOUNT==159);
  }

  FrasInstall(FRAS_MEDIUM_FRQ);
  FrasPlayMod(&CountryModInfo);
  Print("Status: Playing",0);

  Print("Press A to pause song",17*32);
  Print("Press B to un-pause song",18*32);
  Print("Press Start to restart song",19*32);
  
  Print("Frame:",32);
  Print("Current pattern:",64);
  Print("Current line:",96);

  unsigned keyA=0;
  unsigned keyB=0;
  unsigned keyStart=0;
  
  unsigned frameCounter=0;
  
  while(1){
    while(REG_VCOUNT!=158);
    while(REG_VCOUNT==159);
    
    if(!(REG_P1&J_A)){
      keyA=J_A;
    }else{
      if(keyA==J_A){
        keyA=0;
        FrasPauseMod();
        Print("Status: Paused ",0);
      }
    }
    
    if(!(REG_P1&J_B)){
      keyB=J_B;
    }else{
      if(keyB==J_B){
        keyB=0;
        FrasUnPauseMod();
        Print("Status: Playing",0);
      }
    }
    
    if(!(REG_P1&J_START)){
      keyStart=J_START;
    }else{
      if(keyStart==J_START){
        keyStart=0;
        FrasPlayMod(&CountryModInfo);
        Print("Status: Playing",0);
      }
    }
    frameCounter++;
    PrintHex(frameCounter,48);
    PrintHex(fras_patternCounter,80);
    PrintHex(fras_currentPatternLine,112);
  }
}
