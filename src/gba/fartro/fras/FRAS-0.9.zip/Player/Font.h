#ifndef FONT_H
#define FONT_H
/* Tile size:        8*8 */
/* Number of tiles:  95 */
/* Number of colors: 16 */

#define FONT_NR_OF_TILES 95
#define FONT_TILESIZE_X 8
#define FONT_TILESIZE_Y 8
#define FONT_TILESIZE 16
#define FONT_PALETTE_COLORS 16

extern const unsigned short FontTileData[95][16];
extern const unsigned short FontPaletteData[16];
#endif //FONT_H
