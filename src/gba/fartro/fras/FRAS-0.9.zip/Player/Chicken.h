#ifndef CHICKEN_H
#define CHICKEN_H
/* Tile size:        8*8 */
/* Number of tiles:  465 */
/* Number of colors: 256 */

#define CHICKEN_NR_OF_TILES 465
#define CHICKEN_TILESIZE_X 8
#define CHICKEN_TILESIZE_Y 8
#define CHICKEN_TILESIZE 32
#define CHICKEN_MAPSIZE_X 30
#define CHICKEN_MAPSIZE_Y 20
#define CHICKEN_MAPSIZE 600
#define CHICKEN_PALETTE_COLORS 256

extern const unsigned short ChickenTileData[465][32];
extern const unsigned short ChickenMapData[600];
extern const unsigned short ChickenPaletteData[256];
#endif //CHICKEN_H
