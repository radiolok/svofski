#ifndef GBAJOY_H
#define GBAJOY_H

#define J_A             0x0001
#define J_B             0x0002
#define J_SELECT        0x0004
#define J_START         0x0008
#define J_RIGHT         0x0010
#define J_LEFT          0x0020
#define J_UP            0x0040
#define J_DOWN          0x0080
#define J_R             0x0100
#define J_L             0x0200

#endif

