#ifndef MOD_H
#define MOD_H

unsigned DoMod(FILE *modFile,char *dataName);

#endif

