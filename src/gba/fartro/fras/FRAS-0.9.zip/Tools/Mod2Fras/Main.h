#ifndef MAIN_H
#define MAIN_H

extern bool showInfo;

#endif

